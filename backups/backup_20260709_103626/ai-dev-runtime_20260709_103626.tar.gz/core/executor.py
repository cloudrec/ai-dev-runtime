from core.file_writer import FileWriter
from core.git_bridge import GitBridge
from core.patch_engine import PatchEngine
from core.safety import approve_action


def execute_plan(plan, context):
    git = GitBridge(context["project_path"])
    patcher = PatchEngine(context["project_path"])

    results = []

    for step in plan.get("steps", []):
        if not approve_action({"step": step}):
            continue

        # v0.4: пока симуляция изменений
        if "logger" in step:
            result = patcher.apply_patch(
                "core/logger.py",
                "print('logger v0.4')"
            )
        else:
            result = {"step": step, "executed": True}

        results.append(result)

    git.add_all()
    git.commit("AI Runtime v0.4 auto commit (safe)")
    # git.push()  # пока отключено для безопасности

    return {
        "executed": True,
        "results": results,
        "git": "committed (no push)"
    }
def execute_plan(plan, context):
    return {
        "executed": False,
        "reason": "safe mode v0.1",
        "plan": plan
    }
