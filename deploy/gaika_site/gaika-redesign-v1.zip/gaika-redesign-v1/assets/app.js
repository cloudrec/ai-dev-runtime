(function () {
  'use strict';
  const translations = window.GAIKA_TRANSLATIONS || {};
  const langs = new Set(['ru', ...Object.keys(translations)]);
  const elements = [...document.querySelectorAll('[data-i18n], [data-i18n-html], [data-i18n-placeholder]')];
  const originals = new Map(elements.map(el => [el, {
    value: el.hasAttribute('data-i18n-html') ? el.innerHTML : el.hasAttribute('data-i18n-placeholder') ? el.getAttribute('placeholder') : el.textContent,
    kind: el.hasAttribute('data-i18n-html') ? 'html' : el.hasAttribute('data-i18n-placeholder') ? 'placeholder' : 'text',
    key: el.getAttribute('data-i18n-html') || el.getAttribute('data-i18n-placeholder') || el.getAttribute('data-i18n')
  }]));
  const stringsRU = { cheapName:'Экономная корзина', balanceName:'Оптимальная корзина', comfortName:'Комфортная корзина',subApproved:'Одобрено только в демо. Корзина магазина не изменена.',subRejected:'Отклонено только в демо. Корзина магазина не изменена.',signupNoCountry:'Сначала выберите страну.',signupCopied:'Анкета скопирована. Публичная регистрация пока не подключена.',signupManual:'Скопируйте данные вручную. Публичная регистрация пока не подключена.' };
  let lang = 'ru';
  function tr(key) { return (lang === 'ru' ? stringsRU[key] : translations[lang]?.[key]) || stringsRU[key] || ''; }
  function setLanguage(code) {
    lang = langs.has(code) ? code : 'ru';
    document.documentElement.lang = lang;
    for (const el of elements) {
      const orig=originals.get(el), next=lang==='ru' ? orig.value : translations[lang]?.[orig.key];
      if (next === undefined || next === null) { if(lang !== 'ru') console.warn('Missing translation:',lang,orig.key); continue; }
      if(orig.kind==='html') el.innerHTML=next;
      else if(orig.kind==='placeholder') el.setAttribute('placeholder', next);
      else el.textContent=next;
    }
    const page=document.body.dataset.page;
    const titles={ru:page==='retailers'?'GAIKA — для ретейлеров':'GAIKA — покупки по вашему списку',en:page==='retailers'?'GAIKA — for retailers':'GAIKA — from list to basket',uk:page==='retailers'?'GAIKA — для ритейлерів':'GAIKA — покупки за вашим списком',de:page==='retailers'?'GAIKA — für Händler':'GAIKA — vom Einkaufszettel zum Warenkorb',pl:page==='retailers'?'GAIKA — dla sieci handlowych':'GAIKA — od listy do koszyka',fr:page==='retailers'?'GAIKA — pour les enseignes':'GAIKA — de la liste au panier'};
    document.title=titles[lang] || titles.en;
    const switcher=document.getElementById('lang-switch'); if(switcher) switcher.value=lang;
    try { localStorage.setItem('gaika-preferred-language',lang); }catch(e){}
    if(location.protocol==='http:' || location.protocol==='https:'){const url=new URL(location.href);url.searchParams.set('lang',lang);history.replaceState(null,'',url.pathname+url.search+url.hash);}
    updatePlan();
  }
  function getInitialLanguage(){const param=new URLSearchParams(location.search).get('lang');if(langs.has(param)) return param;try{const saved=localStorage.getItem('gaika-preferred-language');if(langs.has(saved))return saved;}catch(e){}const primary=(navigator.language||'ru').toLowerCase().split('-')[0];return langs.has(primary)?primary:'ru';}
  const switcher=document.getElementById('lang-switch');if(switcher) switcher.addEventListener('change',e=>setLanguage(e.target.value));
  const plans={cheap:{price:'≈ €24,80',name:'cheapName'},balance:{price:'≈ €27,40',name:'balanceName'},comfort:{price:'≈ €30,10',name:'comfortName'}};
  let selectedPlan='balance';
  function updatePlan(){const price=document.getElementById('plan-price');if(!price)return;price.textContent=plans[selectedPlan].price;document.getElementById('total-price').textContent=plans[selectedPlan].price;document.getElementById('plan-title').textContent=tr(plans[selectedPlan].name);}
  for(const btn of document.querySelectorAll('[data-plan]')) btn.addEventListener('click',()=>{selectedPlan=btn.dataset.plan;for(const el of document.querySelectorAll('[data-plan]')){el.classList.toggle('active',el===btn);el.setAttribute('aria-pressed',String(el===btn));}updatePlan()});
  const feedback=document.getElementById('sub-feedback');const approve=document.getElementById('approve-sub'),reject=document.getElementById('reject-sub');
  if(approve&&reject&&feedback){for(const btn of [approve,reject])btn.addEventListener('click',()=>{approve.setAttribute('aria-pressed',String(btn===approve));reject.setAttribute('aria-pressed',String(btn===reject));feedback.textContent=tr(btn===approve?'subApproved':'subRejected');});}
  document.getElementById('interest-form')?.addEventListener('submit',async event=>{
    event.preventDefault();const country=document.getElementById('signup-country').value;const store=document.getElementById('signup-store').value.trim();const message=document.getElementById('signup-message');
    if(!country){message.textContent=tr('signupNoCountry');document.getElementById('signup-country').focus();return;}
    const value=`GAIKA early access interest\nCountry: ${country}\nStore: ${store||'Not specified'}\nThis is NOT a completed registration.`;
    try{await navigator.clipboard.writeText(value);message.textContent=tr('signupCopied');}
    catch(e){message.textContent=`${tr('signupManual')} ${value.replace(/\n/g,' · ')}`;}
  });
  document.querySelectorAll('.mobile-nav-pop a').forEach(a=>a.addEventListener('click',()=>a.closest('details').open=false));
  setLanguage(getInitialLanguage());
})();
