from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import functools, threading
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).parent
out=[]
server=ThreadingHTTPServer(("127.0.0.1",0),functools.partial(SimpleHTTPRequestHandler,directory=str(root)))
threading.Thread(target=server.serve_forever,daemon=True).start()
base=f"http://127.0.0.1:{server.server_port}/"
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for page_name in ['index.html','retailers.html']:
  for w,h in [(1440,900),(768,900),(390,844),(320,740)]:
   page=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
   messages=[]; errs=[]
   page.on('console',lambda msg: messages.append(msg.text) if msg.type=='warning' else None)
   page.on('pageerror',lambda e: errs.append(str(e)))
   page.set_content((root/page_name).read_text(),wait_until='domcontentloaded')
   page.evaluate('(css) => { const el=document.createElement("style"); el.textContent=css; document.head.appendChild(el); }',(root/'assets/styles.css').read_text())
   page.add_script_tag(content=(root/'assets/i18n.js').read_text())
   page.add_script_tag(content=(root/'assets/app.js').read_text())
   page.wait_for_timeout(150)
   data=page.evaluate('''() => ({width:innerWidth, scrollWidth:document.documentElement.scrollWidth, bodyScrollWidth:document.body.scrollWidth, text:document.querySelector('h1').innerText.slice(0,80)})''')
   assert data['scrollWidth'] <= w+1, (page_name,w,data)
   assert not errs,(page_name,w,errs)
   if w in (1440,390):
    page.screenshot(path=str(root/f'{page_name.split(".")[0]}-{w}.png'),full_page=True)
   for lang in ['en','uk','pl','de','fr','ru']:
    page.locator('#lang-switch').select_option(lang)
    assert page.evaluate('document.documentElement.lang')==lang
    assert page.locator('h1').inner_text().strip()
    expanded=page.evaluate('document.documentElement.scrollWidth')
    assert expanded<=w+1,(page_name,w,lang,expanded)
    if lang!='ru':
     assert not any('Missing translation' in x for x in messages), (page_name,lang,[x for x in messages if 'Missing translation' in x])
   if w in (1440,390): page.screenshot(path=str(root/f'{page_name.split(".")[0]}-ru-{w}.png'),full_page=True)
   if page_name=='index.html':
    page.locator('[data-plan="cheap"]').click()
    assert '24,80' in page.locator('#total-price').inner_text()
    page.locator('#reject-sub').click()
    assert page.locator('#sub-feedback').inner_text()
    page.locator('#signup-country').select_option('DE')
    page.locator('#signup-store').fill('Rewe')
    page.locator('#interest-form button[type=submit]').click()
    assert page.locator('#signup-message').inner_text()
   out.append({'page':page_name,'viewport':w,'width':data['scrollWidth'],'errors':errs,'translations':'en,uk,pl,de,fr,ru passed'})
   page.close()
 b.close()
server.shutdown()
print(json.dumps(out,indent=2,ensure_ascii=False))
